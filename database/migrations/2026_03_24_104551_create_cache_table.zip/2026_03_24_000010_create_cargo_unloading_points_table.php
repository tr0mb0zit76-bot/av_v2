// database/migrations/2026_03_24_000010_create_cargo_unloading_points_table.php
<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    public function up(): void
    {
        Schema::create('cargo_unloading_points', function (Blueprint $table) {
            $table->id();
            $table->foreignId('cargo_id')->constrained()->onDelete('cascade');
            $table->foreignId('route_point_id')->constrained()->onDelete('cascade');
            $table->decimal('quantity', 12, 4)->comment('Количество, выгружаемое в этой точке');
            $table->timestamp('unloaded_at')->nullable();
            $table->text('notes')->nullable();
            $table->timestamps();
            
            $table->index(['cargo_id', 'route_point_id']);
            $table->index('route_point_id');
        });
    }

    public function down(): void
    {
        Schema::dropIfExists('cargo_unloading_points');
    }
};