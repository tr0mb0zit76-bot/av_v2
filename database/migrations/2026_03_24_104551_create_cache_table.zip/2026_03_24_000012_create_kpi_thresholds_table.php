// database/migrations/2026_03_24_000012_create_kpi_thresholds_table.php
<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    public function up(): void
    {
        Schema::create('kpi_thresholds', function (Blueprint $table) {
            $table->id();
            $table->string('deal_type', 50);
            $table->decimal('threshold_from', 5, 2);
            $table->decimal('threshold_to', 5, 2);
            $table->integer('kpi_percent');
            $table->boolean('is_active')->default(true);
            $table->timestamps();
            
            $table->unique(['deal_type', 'threshold_from', 'threshold_to'], 'unique_kpi_threshold_range');
            $table->index(['deal_type', 'is_active']);
            $table->index(['threshold_from', 'threshold_to']);
        });
    }

    public function down(): void
    {
        Schema::dropIfExists('kpi_thresholds');
    }
};