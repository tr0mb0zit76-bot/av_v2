// database/migrations/2026_03_24_000005_create_cargos_table.php
<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    public function up(): void
    {
        Schema::create('cargos', function (Blueprint $table) {
            $table->id();
            $table->string('title', 500)->index();
            $table->text('description')->nullable();
            $table->decimal('weight', 10, 2)->nullable()->index();
            $table->decimal('volume', 10, 2)->nullable();
            $table->string('cargo_type', 100)->nullable();
            $table->unsignedInteger('cargo_type_id')->nullable()->comment('ID из словаря АТИ');
            $table->string('packing_type', 100)->nullable();
            $table->unsignedInteger('pack_type_id')->nullable()->comment('ID из словаря АТИ');
            $table->integer('pallet_count')->nullable();
            $table->integer('belt_count')->nullable();
            $table->decimal('length', 10, 2)->nullable();
            $table->decimal('width', 10, 2)->nullable();
            $table->decimal('height', 10, 2)->nullable();
            $table->boolean('is_hazardous')->default(false);
            $table->string('hazard_class', 10)->nullable();
            $table->boolean('needs_temperature')->default(false);
            $table->decimal('temp_min', 5, 2)->nullable();
            $table->decimal('temp_max', 5, 2)->nullable();
            $table->boolean('needs_hydraulic')->default(false);
            $table->boolean('needs_manipulator')->default(false);
            $table->text('special_instructions')->nullable();
            $table->json('photos')->nullable();
            $table->json('documents')->nullable();
            $table->unsignedBigInteger('ati_load_id')->nullable()->index();
            $table->timestamp('ati_published_at')->nullable();
            $table->json('ati_response')->nullable();
            $table->text('source_text')->nullable();
            $table->string('source_file', 500)->nullable();
            $table->boolean('parsed_by_ai')->default(false);
            $table->timestamp('parsed_at')->nullable();
            $table->foreignId('created_by')->nullable()->constrained('users')->nullOnDelete();
            $table->foreignId('updated_by')->nullable()->constrained('users')->nullOnDelete();
            $table->timestamps();
        });
    }

    public function down(): void
    {
        Schema::dropIfExists('cargos');
    }
};