// database/migrations/2026_03_24_000020_create_ai_knowledge_index_table.php
<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    public function up(): void
    {
        Schema::create('ai_knowledge_index', function (Blueprint $table) {
            $table->id();
            $table->enum('source_type', ['order', 'document', 'contractor', 'driver', 'kpi_pattern', 'message']);
            $table->unsignedBigInteger('source_id');
            $table->string('vector_id')->index();
            $table->string('content_hash', 64);
            $table->json('metadata')->nullable();
            $table->timestamp('indexed_at')->nullable()->index();
            $table->timestamps();
            
            $table->unique(['source_type', 'source_id'], 'source_unique');
        });
    }

    public function down(): void
    {
        Schema::dropIfExists('ai_knowledge_index');
    }
};