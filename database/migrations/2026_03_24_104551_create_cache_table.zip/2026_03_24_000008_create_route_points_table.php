// database/migrations/2026_03_24_000008_create_route_points_table.php
<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    public function up(): void
    {
        Schema::create('route_points', function (Blueprint $table) {
            $table->id();
            $table->foreignId('order_leg_id')->constrained()->onDelete('cascade');
            $table->enum('type', ['loading', 'unloading', 'transit', 'customs', 'warehouse'])->default('transit');
            $table->integer('sequence')->default(0);
            $table->string('city', 255)->nullable();
            $table->text('address')->nullable();
            $table->string('kladr_id', 255)->nullable();
            $table->decimal('latitude', 10, 8)->nullable();
            $table->decimal('longitude', 11, 8)->nullable();
            $table->date('planned_date')->nullable();
            $table->time('planned_time_from')->nullable();
            $table->time('planned_time_to')->nullable();
            $table->date('actual_date')->nullable();
            $table->time('actual_time')->nullable();
            $table->string('contact_person', 255)->nullable();
            $table->string('contact_phone', 50)->nullable();
            $table->text('instructions')->nullable();
            $table->json('metadata')->nullable();
            $table->timestamps();
            
            $table->index(['order_leg_id', 'sequence']);
            $table->index(['order_leg_id', 'type']);
        });
    }

    public function down(): void
    {
        Schema::dropIfExists('route_points');
    }
};