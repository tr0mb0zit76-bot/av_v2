// database/migrations/2026_03_24_000019_create_ai_order_drafts_table.php
<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    public function up(): void
    {
        Schema::create('ai_order_drafts', function (Blueprint $table) {
            $table->id();
            $table->foreignId('user_id')->constrained()->onDelete('cascade');
            $table->foreignId('conversation_id')->nullable()->constrained('ai_conversations')->nullOnDelete();
            $table->foreignId('order_id')->nullable()->constrained()->nullOnDelete();
            $table->json('parsed_data');
            $table->json('edited_data')->nullable();
            $table->json('ai_suggestions')->nullable();
            $table->enum('status', ['draft', 'confirmed', 'edited', 'cancelled'])->default('draft')->index();
            $table->enum('source', ['text', 'file', 'email', 'telegram'])->default('text');
            $table->string('source_file', 500)->nullable();
            $table->timestamp('confirmed_at')->nullable();
            $table->timestamps();
        });
    }

    public function down(): void
    {
        Schema::dropIfExists('ai_order_drafts');
    }
};