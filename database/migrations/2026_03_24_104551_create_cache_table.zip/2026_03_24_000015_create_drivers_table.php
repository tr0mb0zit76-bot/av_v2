// database/migrations/2026_03_24_000015_create_drivers_table.php
<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    public function up(): void
    {
        Schema::create('drivers', function (Blueprint $table) {
            $table->id();
            $table->string('first_name');
            $table->string('last_name');
            $table->string('patronymic')->nullable();
            $table->string('phone', 50)->nullable();
            $table->string('email', 255)->nullable();
            $table->string('license_number')->nullable();
            $table->date('license_expiry')->nullable();
            $table->foreignId('contractor_id')->nullable()->constrained()->nullOnDelete();
            $table->json('metadata')->nullable();
            $table->boolean('is_active')->default(true);
            $table->timestamps();
            
            $table->index('phone');
            $table->index('contractor_id');
        });
    }

    public function down(): void
    {
        Schema::dropIfExists('drivers');
    }
};