// database/migrations/2026_03_24_000004_create_contractors_table.php
<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    public function up(): void
    {
        Schema::create('contractors', function (Blueprint $table) {
            $table->id();
            $table->enum('type', ['customer', 'carrier', 'both'])->default('both');
            $table->string('name');
            $table->string('full_name')->nullable();
            $table->string('inn', 20)->nullable()->index();
            $table->string('kpp', 20)->nullable();
            $table->string('ogrn', 20)->nullable();
            $table->string('okpo', 20)->nullable();
            $table->enum('legal_form', ['ooо', 'zao', 'ao', 'ip', 'samozanyaty', 'other'])->nullable();
            $table->string('legal_address')->nullable();
            $table->string('actual_address')->nullable();
            $table->string('postal_address')->nullable();
            $table->string('phone', 50)->nullable()->index();
            $table->string('email', 255)->nullable()->index();
            $table->string('website', 255)->nullable();
            $table->string('contact_person')->nullable();
            $table->string('contact_person_phone', 50)->nullable();
            $table->string('contact_person_email', 255)->nullable();
            $table->string('contact_person_position')->nullable();
            $table->string('bank_name')->nullable();
            $table->string('bik', 9)->nullable();
            $table->string('account_number', 20)->nullable();
            $table->string('correspondent_account', 20)->nullable();
            $table->json('ati_profiles')->nullable();
            $table->string('ati_id', 50)->nullable();
            $table->json('transport_requirements')->nullable();
            $table->json('specializations')->nullable();
            $table->decimal('rating', 3, 2)->default(0);
            $table->integer('completed_orders')->default(0);
            $table->json('metadata')->nullable();
            $table->boolean('is_active')->default(true)->index();
            $table->boolean('is_verified')->default(false);
            $table->foreignId('created_by')->nullable()->constrained('users')->nullOnDelete();
            $table->foreignId('updated_by')->nullable()->constrained('users')->nullOnDelete();
            $table->timestamps();
            
            $table->index(['type', 'is_active']);
            $table->index('name');
        });
    }

    public function down(): void
    {
        Schema::dropIfExists('contractors');
    }
};