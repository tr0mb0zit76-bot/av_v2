// database/migrations/2026_03_24_000018_create_ai_attachments_table.php
<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    public function up(): void
    {
        Schema::create('ai_attachments', function (Blueprint $table) {
            $table->id();
            $table->foreignId('message_id')->constrained('ai_messages')->onDelete('cascade');
            $table->string('original_name');
            $table->string('stored_name');
            $table->string('path', 500);
            $table->string('mime_type', 100)->nullable();
            $table->integer('size')->nullable();
            $table->string('disk', 50)->default('local');
            $table->json('extracted_data')->nullable();
            $table->string('vector_id')->nullable();
            $table->string('status', 50)->default('pending')->index();
            $table->timestamps();
        });
    }

    public function down(): void
    {
        Schema::dropIfExists('ai_attachments');
    }
};