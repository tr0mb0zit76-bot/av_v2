// database/migrations/2026_03_24_000006_create_orders_table.php
<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    public function up(): void
    {
        Schema::create('orders', function (Blueprint $table) {
            $table->id();
            $table->string('order_number')->nullable()->index();
            $table->string('company_code', 10)->nullable()->index();
            $table->foreignId('manager_id')->nullable()->constrained('users')->nullOnDelete();
            $table->foreignId('site_id')->nullable()->constrained()->nullOnDelete();
            $table->date('order_date')->nullable()->index();
            $table->date('loading_date')->nullable()->index();
            $table->date('unloading_date')->nullable()->index();
            
            // Финансы (очищено от дублирования)
            $table->decimal('customer_rate', 12, 2)->nullable();
            $table->string('customer_payment_form', 50)->nullable();
            $table->string('customer_payment_term', 50)->nullable();
            $table->decimal('carrier_rate', 12, 2)->nullable();
            $table->string('carrier_payment_form', 50)->nullable();
            $table->string('carrier_payment_term', 50)->nullable();
            $table->decimal('additional_expenses', 12, 2)->default(0);
            $table->decimal('insurance', 12, 2)->default(0);
            $table->decimal('bonus', 12, 2)->default(0);
            
            // KPI (будет пересчитываться)
            $table->decimal('kpi_percent', 5, 2)->nullable();
            $table->decimal('delta', 12, 2)->nullable();
            $table->decimal('salary_accrued', 12, 2)->default(0);
            $table->decimal('salary_paid', 12, 2)->default(0);
            
            // Статусы
            $table->string('status', 50)->default('new')->index();
            $table->boolean('is_active')->default(true);
            
            // Связи (чистые внешние ключи)
            $table->foreignId('customer_id')->nullable()->constrained('contractors')->nullOnDelete();
            $table->foreignId('carrier_id')->nullable()->constrained('contractors')->nullOnDelete();
            $table->foreignId('driver_id')->nullable()->constrained('drivers')->nullOnDelete();
            
            // AI
            $table->foreignId('ai_draft_id')->nullable()->index();
            $table->decimal('ai_confidence', 5, 2)->nullable();
            $table->json('ai_metadata')->nullable();
            $table->json('ati_response')->nullable();
            $table->string('ati_load_id')->nullable()->unique();
            $table->timestamp('ati_published_at')->nullable();
            
            // Документооборот (нормализовано)
            $table->string('invoice_number')->nullable();
            $table->string('upd_number')->nullable();
            $table->string('waybill_number')->nullable();
            
            // Метки аудита
            $table->foreignId('created_by')->nullable()->constrained('users')->nullOnDelete();
            $table->foreignId('updated_by')->nullable()->constrained('users')->nullOnDelete();
            $table->json('metadata')->nullable();
            $table->json('payment_statuses')->nullable();
            
            $table->timestamps();
            
            // Составные индексы
            $table->index(['manager_id', 'order_date']);
            $table->index(['status', 'is_active']);
        });
    }

    public function down(): void
    {
        Schema::dropIfExists('orders');
    }
};