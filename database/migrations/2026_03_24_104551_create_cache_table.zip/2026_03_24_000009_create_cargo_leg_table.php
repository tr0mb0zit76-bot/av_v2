// database/migrations/2026_03_24_000009_create_cargo_leg_table.php
<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    public function up(): void
    {
        Schema::create('cargo_leg', function (Blueprint $table) {
            $table->id();
            $table->foreignId('cargo_id')->constrained()->onDelete('cascade');
            $table->foreignId('order_leg_id')->constrained()->onDelete('cascade');
            $table->decimal('quantity', 12, 4)->default(1);
            $table->enum('status', ['planned', 'loaded', 'unloaded', 'damaged', 'lost'])->default('planned');
            $table->text('notes')->nullable();
            $table->timestamps();
            
            $table->unique(['cargo_id', 'order_leg_id']);
            $table->index(['order_leg_id', 'status']);
        });
    }

    public function down(): void
    {
        Schema::dropIfExists('cargo_leg');
    }
};